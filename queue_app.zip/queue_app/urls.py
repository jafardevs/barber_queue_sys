from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register_view, name='register'),
    path('', views.queue_list_view, name='queue_list'),
    path('finish/<int:customer_id>/', views.finish_customer_view, name='finish_customer'),
]
